/*
 * Copyright 2013-2017 (c) MuleSoft, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */
package org.raml.jaxrs.generator.v10;

import org.raml.v2.api.model.v10.datamodel.XMLFacetInfo;
import org.raml.v2.api.model.v10.declarations.AnnotationRef;

import java.util.Collections;
import java.util.List;

/**
 * Created by Jean-Philippe Belanger on 3/19/17. Just potential zeroes and ones
 */
public class NullXMLFacetInfo implements XMLFacetInfo {

  @Override
  public Boolean attribute() {
    return false;
  }

  @Override
  public Boolean wrapped() {
    return false;
  }

  @Override
  public String name() {
    return null;
  }

  @Override
  public String namespace() {
    return null;
  }

  @Override
  public String prefix() {
    return null;
  }

  @Override
  public List<AnnotationRef> annotations() {
    return Collections.emptyList();
  }
}
