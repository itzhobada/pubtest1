## GSon annotations
Currently, Gson is only rudimentarily supported.

### Properties
Annotation | Placement |
-----------|:----------|
`@SerializedName`| Placed on fields for properties |
`@Exposed` | Placed on fields for properties |


That is all.
